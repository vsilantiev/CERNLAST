
           Core name: Xilinx Virtex-6 Integrated Block for PCI Express
           Version: 1.6
           Release Date: September 21, 2010


================================================================================

This document contains the following sections:

1. Introduction
2. New Features
3. Supported Devices
4. Resolved Issues
5. Known Issues
6. Technical Support
7. Other Information
8. Core Release History
9. Legal Disclaimer

================================================================================

1. INTRODUCTION

For the most recent updates to the IP installation instructions for this core,
please go to:

   http://www.xilinx.com/ipcenter/coregen/ip_update_install_instructions.htm


For system requirements:

   http://www.xilinx.com/ipcenter/coregen/ip_update_system_requirements.htm


This file contains release notes for the Xilinx LogiCORE(TM) IP Virtex-6
Integrated Block for PCI Express v1.6 solution. For the latest core updates,
see the product page at:

   http://www.xilinx.com/products/ipcenter/V6_PCI_Express_Block.htm


2. NEW FEATURES

   - ISE 12.3 software support
   - QPro Virtex-6 Hi-Rel device support
   - Enabled ISE Simulator (ISIM) support


3. SUPPORTED DEVICES

- Virtex-6 LXT
- Virtex-6 SXT
- Virtex-6 HXT
- Virtex-6 CXT
- Virtex-6 Lower Power
- QPro Virtex-6 Hi-Rel

4. RESOLVED ISSUES

   - Synplify flow now supported for entire synthesis / implementation
     o CR 531976

     Synplify flow is now supported for complete synthesis and implementation
     process.

   - Added support for QPro Virtex-6 Hi-Rel devices
     o CR 551821

     Support for all QPro Virtex-6 Hi-Rel devices has now been enabled.

   - Added support for ISE Simulator (ISIM)
     o CR 448851

     Support has been enabled for ISE Simulator (ISIM).

   - 8-lane Gen2 product is now supported in the Virtex-6 HXT devices.
     o CR 531975

     Support for 8-lane Gen2 product, in Virtex-6 HXT devices is now available.

   - GTX Production Settings Updated
     o CR 556498

     GTX settings have been updated per Production GTX settings, based on
     PCI Express protocol characterization.

   - GUI support for 8-lane Gen2 configuration
     o CR 563396

     Issue resolved where GUI did not allow generation of an 8-lane Gen2 design
     for an LX365T-3 device and allowed generation of an 8-lane Gen2 design for
     a LX550T-2 device, which is not supported.

   - GUI support for PCIe Block locations for SX315T-FF1156
     o CR 560140

     Issue resolved where the GUI claimed 4 PCIe Block locations available on
     the SX315T-FF1156, whereas this device only has 2 available PCIe Blocks.

   - Use of corename "core" in VHDL design causing implementation failure
     o CR 538681, 569546

     Issue resolved where use of corename "core" for a VHDL design caused
     implementation failures. The use of corename "core_i" is however
     disabled, as this is used as the instance name of the core in the VHDL
     design.

   - Updates to improve timing on Root Port configuration
     o CR 572179

     Updates have been made to implementation scripts and delivered UCFs to
     improve timing on the Root Port configuration design.

   - Default simulation test has been upgraded
     o CR 571632, 532234

     Default simulation test has been upgraded to include memory and IO
     reads and writes.

   - cfg_msg_* interface ports on Root Port Model now visible
     o CR 571176

     cfg_msg_* ports are now visible at the top level of the Root Port Model
     delivered with Endpoint product.

   - cfg_wr_rw1c_as_rw_n port in Root Port product now connected to Hard Block
     o CR 571018

     cfg_wr_rw1c_as_rw_n port in the Root Port product is now connected to the
     port on the Integrated Block for PCI Express.

   - 128-bit wrapper back-pressure on User Interface when Block is full
     o CR 569361

     Issue resolved where the 128-bit wrapper was not back pressuring the User
     Interface when the Transmit buffers were full, causing data loss.

   - User non-posted OK signal undriven in VHDL Root Port model
     o CR 568793

     Issue resolved where the User non-posted OK signal was undriven in the
     VHDL Root Port model, preventing memory read transactions from passing to
     the User Interface.

   - Fixed missing default case statement in FSM in 128bit PIO example design
     o CR 567366

     Issue resolved where the default case statement was missing in the FSM in
     the 128bit PIO example design.

   - Redeclaration of signals in VHDL instantiation template
     o CR 555620

     Issue resolved where the signals were re-declared in the VHDL
     instantiation template, causing synthesis errors when used.



5. KNOWN ISSUES

   The following are known issues for v1.6 of this core at time of release:

    5.1  Functional Issues


    5.2  Simulation Issues


    5.3  Implementation Issues


           - Timing Closure

            In order to obtain timing closure, designers may be required to use
            multiple PAR seeds and/or floorplanning. Using Multi-Pass Place and
            Route (MPPR), designers can try multiple cost tables in order to meet
            timing. Please see the Development System Reference Guide in the
            Software Manuals found at: http://www.xilinx.com/support/library.htm
            for more information on using MPPR. Designers may also have to
            floorplan and add advanced placement constraints for both their
            design and the core to meet timing.


  The most recent information, including known issues, workarounds, and
  resolutions for this version is provided in the IP Release Notes Guide located at

   http://www.xilinx.com/support/documentation/user_guides/xtp025.pdf

6. TECHNICAL SUPPORT

   To obtain technical support, create a WebCase at www.xilinx.com/support.
   Questions are routed to a team with expertise using this product.

   Xilinx provides technical support for use of this product when used
   according to the guidelines described in the core documentation, and
   cannot guarantee timing, functionality, or support of this product for
   designs that do not follow specified guidelines.


7. OTHER INFORMATION


8. CORE RELEASE HISTORY

Date        By            Version      Description
================================================================================
09/21/2010  Xilinx, Inc.  1.6           12.3 support
07/23/2010  Xilinx, Inc.  1.5 Rev 1     Patch Release
04/19/2010  Xilinx, Inc.  1.5           12.1 support
03/09/2010  Xilinx, Inc.  1.4 Rev 3     Patch Release
03/09/2010  Xilinx, Inc.  1.4 Rev 2     11.5 support
12/02/2009  Xilinx, Inc.  1.4 Rev 1     Patch Release
12/02/2009  Xilinx, Inc.  1.4           11.4 support
09/16/2009  Xilinx, Inc.  1.3           11.3 support
06/24/2009  Xilinx, Inc.  1.2           11.2 support
04/24/2009  Xilinx, Inc.  1.1           Initial release (BETA)
================================================================================

9. Legal Disclaimer

(c) Copyright 2009 - 2010 Xilinx, Inc. All rights reserved.

This file contains confidential and proprietary information
of Xilinx, Inc. and is protected under U.S. and
international copyright and other intellectual property
laws.

DISCLAIMER
This disclaimer is not a license and does not grant any
rights to the materials distributed herewith. Except as
otherwise provided in a valid license issued to you by
Xilinx, and to the maximum extent permitted by applicable
law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
(2) Xilinx shall not be liable (whether in contract or tort,
including negligence, or under any other theory of
liability) for any loss or damage of any kind or nature
related to, arising under or in connection with these
materials, including for any direct, or any indirect,
special, incidental, or consequential loss or damage
(including loss of data, profits, goodwill, or any type of
loss or damage suffered as a result of any action brought
by a third party) even if such damage or loss was
reasonably foreseeable or Xilinx had been advised of the
possibility of the same.

CRITICAL APPLICATIONS
Xilinx products are not designed or intended to be fail-
safe, or for use in any application requiring fail-safe
performance, such as life-support or safety devices or
systems, Class III medical devices, nuclear facilities,
applications related to the deployment of airbags, or any
other applications that could lead to death, personal
injury, or severe property or environmental damage
(individually and collectively, "Critical
Applications"). Customer assumes the sole risk and
liability of any use of Xilinx products in Critical
Applications, subject only to applicable laws and
regulations governing limitations on product liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
PART OF THIS FILE AT ALL TIMES.

